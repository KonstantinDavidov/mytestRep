#include "response.h"
#include "ui_response.h"
#include "qxmlputget.h"

Response::Response(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Response)
{
    ui->setupUi(this);

    GetISBResponse();
    GetDSPResponse();
    GetErrorResponse();
}

void Response::GetISBResponse()
{

    QString str1;
    QString str2;
    QString str3;
    QString str4;
    QString str5;
    QString str6;
    QString str7;
    QString str8;
    QString str9;
    QString str10;
    QString str11;
    QString str12;
    QString str13;

    QString file = "/users/jamesreid/ccpor_export/DSP917_Response.xml";

    QXmlGet xmlGet;
    xmlGet.load(file);
    xmlGet.find("dsp917cajudrespip:DSP917CAJUDRespInput");
    xmlGet.findNext("tnshdr:ISBCommonServiceHeader");
    xmlGet.descend();
    if (xmlGet.find("Source"))
    str1 = xmlGet.getString();
    if (xmlGet.find("Target"))
    str2 = xmlGet.getString();
    if (xmlGet.find("InterfaceName"))
    str3 = xmlGet.getString();
    if (xmlGet.find("DocumentType"))
    str4 = xmlGet.getString();
    if (xmlGet.find("DocumentId"))
    str5 = xmlGet.getString();
    if (xmlGet.find("CorrelationId"))
    str6 = xmlGet.getString();
    if (xmlGet.find("DistributionId"))
    str7 = xmlGet.getString();
    if (xmlGet.find("ISBTransactionId"))
    str8 = xmlGet.getString();
    if (xmlGet.find("Environment"))
    str9 = xmlGet.getString();
    if (xmlGet.find("Hostname"))
    str10 = xmlGet.getString();
    if (xmlGet.find("CourtCd"))
    str12 = xmlGet.getString();
    if (xmlGet.find("UserId"))
    str13 = xmlGet.getString();

    ui->lineEdit_source->setText(str1);
    ui->lineEdit_target->setText(str2);
    ui->lineEdit_interfaceName->setText(str3);
    ui->lineEdit_documentType->setText(str4);
    ui->lineEdit_documentID->setText(str5);
    ui->lineEdit_correlationID->setText(str6);
    ui->lineEdit_distributionID->setText(str7);
    ui->lineEdit_ISBTransactionId->setText(str8);
    ui->lineEdit_environment->setText(str9);
    ui->lineEdit_hostname->setText(str10);
    ui->lineEdit_courtCode->setText(str12);
    ui->lineEdit_userID->setText(str13);

    QString timestamp = QDateTime::currentDateTime().toString(Qt::ISODate);
    ui->lineEdit_timeStamp->setText(timestamp);

}

void Response::GetDSPResponse()
{
    QString str1;
    QString str2;
    QString str3;
    QString file = "/users/jamesreid/ccpor_export/DSP917_Response.xml";

    QXmlGet xmlGet;
    xmlGet.load(file);
    xmlGet.find("dsp917cajudrespip:DSP917CAJUDRespInput");
    xmlGet.descend();
    xmlGet.findNext("dsp917cajudresp:ProductExchangePackage");
    xmlGet.descend();
    xmlGet.findNext("dsp917cajudresp:ProductExchangeResponseActivity");
    xmlGet.descend();
    if (xmlGet.find("dsp917cajudresp:ControlNumber"))
    str1 = xmlGet.getString();
    if (xmlGet.find("dsp917cajudresp:OrderIdentification"))
    xmlGet.descend();
    if (xmlGet.find("ncresp:IdentificationID"));
    str2 = xmlGet.getString();
    xmlGet.rise();
    if (xmlGet.find("dsp917cajudresp:CaseRestrainingOrder"))
    xmlGet.descend();
    if (xmlGet.find("ncresp:ActivityCategoryText"))
    str3 = xmlGet.getString();


    ui->lineEdit_controlNumber->setText(str1);
    ui->lineEdit_ccporID->setText(str2);
    ui->lineEdit_orderType->setText(str3);

}

void Response::GetErrorResponse()
{
     QString str1;
     QString str2;
     QString file = "/users/jamesreid/ccpor_export/DSP917_Error_Response.xml";

     QXmlGet xmlGet;
     xmlGet.load(file);
     xmlGet.find("dsp917cajudrespip:DSP917CAJUDRespInput");
     xmlGet.descend();
     xmlGet.findNext("dsp917cajudresp:ProductExchangePackage");
     xmlGet.descend();
     xmlGet.findNext("dsp917cajudresp:ProductExchangeErrorActivity");
     xmlGet.descend();
     xmlGet.findNext("dsp917cajudresp:ErrorInformation");
     xmlGet.descend();
     if (xmlGet.find("dsp917cajudresp:ErrorInformationMessageCode"))
     str1 = xmlGet.getString();
     if (xmlGet.find("dsp917cajudresp:ErrorInformationMessageText"))
     str2 = xmlGet.getString();

     ui->lineEdit_error->setText(str1);
     ui->textEdit->setPlainText(str2);

}

Response::~Response()
{
    delete ui;
}


