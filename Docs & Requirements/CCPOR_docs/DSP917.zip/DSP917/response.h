#ifndef RESPONSE_H
#define RESPONSE_H

#include <QDialog>

namespace Ui {
class Response;
}

class Response : public QDialog
{
    Q_OBJECT


void GetISBResponse();
void GetDSPResponse();
void GetErrorResponse();

public:
    explicit Response(QWidget *parent = 0);
    ~Response();
    
private:
    Ui::Response *ui;
};

#endif // RESPONSE_H
