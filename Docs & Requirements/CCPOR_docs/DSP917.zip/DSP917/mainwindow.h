#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT


void RequestLoadISB();
void saveFile();
void RequestLoadCase();


public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
    
private slots:
    void on_toolButton_2_clicked();

    void on_toolButton_loadXML_clicked();

    void on_toolButton_clicked();

    void on_toolButton_saveCCPOR_clicked();

    void on_toolButton_Response_clicked();

private:
    Ui::MainWindow *ui;
};

#endif // MAINWINDOW_H
