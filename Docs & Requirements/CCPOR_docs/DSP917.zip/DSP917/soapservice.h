#ifndef SOAPSERVICE_H
#define SOAPSERVICE_H

#include <QDialog>

namespace Ui {
class SoapService;
}

class SoapService : public QDialog
{
    Q_OBJECT
    
public:
    explicit SoapService(QWidget *parent = 0);
    ~SoapService();
    
private:
    Ui::SoapService *ui;
};

#endif // SOAPSERVICE_H
