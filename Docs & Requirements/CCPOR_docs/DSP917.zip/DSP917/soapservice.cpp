#include "soapservice.h"
#include "ui_soapservice.h"

SoapService::SoapService(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::SoapService)
{
    ui->setupUi(this);
}

SoapService::~SoapService()
{
    delete ui;
}
