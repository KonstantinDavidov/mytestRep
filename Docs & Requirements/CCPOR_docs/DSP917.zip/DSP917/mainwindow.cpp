#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "qxmlputget.h"
#include "response.h"
#include <QDateTime>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

//GET ISODATE QDATE
    QString timestamp = QDateTime::currentDateTime().toString(Qt::ISODate);
    ui->lineEdit_currentTime->setText(timestamp);
}


//ACTION TO SAVE CCPOR XML FORMAT
void MainWindow::on_toolButton_saveCCPOR_clicked()
{
    saveFile();
}

//ACTION TO OPEN A RESPONSE DIALOG
void MainWindow::on_toolButton_Response_clicked()
{
   Response nResponse;
   nResponse.setModal(true);
   nResponse.exec();
}

//ACTION TO LOAD A CCPOR XML FILE
void MainWindow::on_toolButton_loadXML_clicked()
{
 RequestLoadISB();
 RequestLoadCase();
}

//FUNCTION LOAD ISB NAMESPACE
void MainWindow::RequestLoadISB()
{
    QString str1;
    QString str2;
    QString str3;
    QString str4;
    QString str5;
    QString str6;
    QString str7;
    QString str8;
    QString str9;
    QString str10;
    QString str11;
    QString str12;
    QString str13;

    QString file = ui->lineEdit_loadFile->text();
    ui->lineEdit_saveFile->setText(file);

    QXmlGet xmlGet;
    xmlGet.load(file);
    xmlGet.find("soapenv:Envelope");
    xmlGet.descend();
    xmlGet.find("soapenv:Body");
    xmlGet.descend();
    xmlGet.find("dsp917cajudreqip:DSP917CAJUDReqInput");
    xmlGet.descend();
    xmlGet.findNext("tnshdr:ISBCommonServiceHeader");
    xmlGet.descend();
    if (xmlGet.find("Source"))
    str1 = xmlGet.getString();
    if (xmlGet.find("Target"))
    str2 = xmlGet.getString();
    if (xmlGet.find("InterfaceName"))
    str3 = xmlGet.getString();
    if (xmlGet.find("DocumentType"))
    str4 = xmlGet.getString();
    if (xmlGet.find("CorrelationId"))
    str5 = xmlGet.getString();
    if (xmlGet.find("ISBTransactionId"))
    str6 = xmlGet.getString();
    if (xmlGet.find("Environment"))
    str7 = xmlGet.getString();
    if (xmlGet.find("Hostname"))
    str8 = xmlGet.getString();
    if (xmlGet.find("TimeStamp"))
    str9 = xmlGet.getString();
    if (xmlGet.find("CourtCd"))
    str10 = xmlGet.getString();
    if (xmlGet.find("UserId"))
    str11 = xmlGet.getString();
    xmlGet.find("RoutingInfo");
    xmlGet.descend();
    if (xmlGet.find("Name"))
    str12 = xmlGet.getString();
    if (xmlGet.find("Value"))
    str13 = xmlGet.getString();
    xmlGet.rise();
    xmlGet.rise();

    ui->lineEdit_source->setText(str1);
    ui->lineEdit_target->setText(str2);
    ui->lineEdit_interfaceName->setText(str3);
    ui->lineEdit_documentType->setText(str4);
    ui->lineEdit_correlationID->setText(str5);
    ui->lineEdit_ISBTransactionId->setText(str6);
    ui->lineEdit_environment->setText(str7);
    ui->lineEdit_hostname->setText(str8);
    ui->lineEdit_timestamp->setText(str9);
    ui->lineEdit_courtCode->setText(str10);
    ui->lineEdit_userID->setText(str11);
    ui->lineEdit_routename->setText(str12);
    ui->lineEdit_routevalue->setText(str13);
}

//FUNCTION TO LOAD THE CASE DATA
void MainWindow::RequestLoadCase()
{
    QString str1;
    QString str2;
    QString str3;
    QString str4;
    QString str5;
    QString str6;
    QString str7;
    QString str8;
    QString str9;
    QString str10;
    QString str11;
    QString str12;
    QString str13;
    QString str14;
    QString str15;
    QString str16;
    QString str17;
    QString str18;
    QString str19;
    QString str20;
    QString str21;
    QString str22;
    QString str23;
    QString str24;
    QString str25;
    QString str26;
    QString str27;
    QString str28;
    QString str29;
    QString str30;
    QString str31;
    QString str32;
    QString str33;
    QString str34;
    QString str35;
    QString str36;
    QString str37;
    QString str38;
    QString str39;
    QString str40;
    QString str41;
    QString str42;
    QString str43;
    QString str44;
    QString str45;
    QString str46;
    QString str47;
    QString str48;
    QString str49;
    QString str50;
    QString str51;
    QString str52;
    QString str53;
    QString str54;
    QString str55;
    QString str56;
    QString str57;
    QString str58;
    QString str59;
    QString file = ui->lineEdit_loadFile->text();

    QXmlGet xmlGet;
    xmlGet.load(file);
    xmlGet.findAndDescend("soapenv:Envelope");
    xmlGet.findAndDescend("soapenv:Body");
    xmlGet.findAndDescend("dsp917cajudreqip:DSP917CAJUDReqInput");
    xmlGet.findAndDescend("dsp917cajudreq:ProductExchangePackage");
    xmlGet.findAndDescend("dsp917cajudreq:ProductRelatedObjects");
    xmlGet.findAndDescend("dsp917cajudreq:ProductRelatedActivities");
    xmlGet.findAndDescend("dsp917cajudreq:CourtCase");
    xmlGet.findAndDescend("ncreq:ActivityDate");
    xmlGet.find("ncreq:Year");
    str1 = xmlGet.getString();
    xmlGet.rise();
    xmlGet.findAndDescend("dsp917cajudreq:CaseAugmentation");
    xmlGet.findAndDescend("jreq:CaseOtherIdentification");
    xmlGet.find("ncreq:IdentificationID");
    str2 = xmlGet.getString();
    xmlGet.rise();
    xmlGet.rise();
    xmlGet.find("ncreq:CaseDocketID");
    str3 = xmlGet.getString();
    xmlGet.findAndDescend("dsp917cajudreq:CaseRestrainingOrder");
    xmlGet.find("ncreq:ActivityCategoryText");
    str4 = xmlGet.getString();
    xmlGet.find("dsp917cajudreq:AddUpdateCancelText");
    str5 = xmlGet.getString();
    xmlGet.find("dsp917cajudreq:ConfidentialCode");
    str6 = xmlGet.getString();
    xmlGet.find("dsp917cajudreq:ContactAllowedCode");
    str7 = xmlGet.getString();
    xmlGet.find("jreq:CourtName");
    str8 = xmlGet.getString();
    xmlGet.findAndDescend("ncreq:ExpirationDate");
    xmlGet.find("ncreq:Date");
    str9 = xmlGet.getString();
    xmlGet.rise();
    xmlGet.find("dsp917cajudreq:FirearmProvisionsCode");
    str10 = xmlGet.getString();
    xmlGet.find("ncreq:IdentificationID");
    str11 = xmlGet.getString();
    xmlGet.find("dsp917cajudreq:IssuanceStateCode");
    str12 = xmlGet.getString();
    xmlGet.findAndDescend("dsp917cajudreq:IssuedDate");
    xmlGet.find("ncreq:Date");
    str13 = xmlGet.getString();
    xmlGet.rise();
    if (xmlGet.find("dsp917cajudreq:NeverExpiresCode"))
    str14 = xmlGet.getString();
    if (xmlGet.find("dsp917cajudreq:PresentInCourtCode"))
    str15 = xmlGet.getString();
    xmlGet.findAndDescend("dsp917cajudreq:RestrainingOrderAttachment");
    xmlGet.find("ncreq:DocumentCategoryText");
    str16 = xmlGet.getString();
    xmlGet.find("ncreq:DocumentDescriptionText");
    str17 = xmlGet.getString();
    xmlGet.rise();
    xmlGet.find("dsp917cajudreq:SealedCode");
    str18 = xmlGet.getString();
    xmlGet.find("dsp917cajudreq:StayAwayText");
    str19 = xmlGet.getString();
    xmlGet.find("dsp917cajudreq:YardsToStayAwayQuantity");
    str20 = xmlGet.getString();
    xmlGet.rise();
    xmlGet.find("dsp917cajudreq:OriginatingAgencyID");
    str21 = xmlGet.getString();
    xmlGet.findAndDescend("dsp917cajudreq:ProtectedParticipant");
    xmlGet.find("dsp917cajudreq:ParticipantCategoryCode");
    str22 = xmlGet.getString();
    xmlGet.rise();
    xmlGet.findAndDescend("dsp917cajudreq:ProtectedParticipant");
    xmlGet.find("dsp917cajudreq:ParticipantCategoryCode");
    str23 = xmlGet.getString();
    xmlGet.rise();
    xmlGet.findAndDescend("dsp917cajudreq:ProtectedParticipant");
    xmlGet.find("dsp917cajudreq:ParticipantCategoryCode");
    str24 = xmlGet.getString();
    xmlGet.rise();
    xmlGet.findAndDescend("dsp917cajudreq:ProtectedParticipant");
    xmlGet.find("dsp917cajudreq:ParticipantCategoryCode");
    str25 = xmlGet.getString();
    xmlGet.rise();
    xmlGet.rise();
    xmlGet.rise();
    xmlGet.findAndDescend("dsp917cajudreq:ProductRelatedContactInformation");
    xmlGet.findAndDescend("dsp917cajudreq:ContactInformation");
    xmlGet.findAndDescend("ncreq:ContactMailingAddress");
    xmlGet.findAndDescend("ncreq:StructuredAddress");
    xmlGet.findAndDescend("dsp917cajudreq:LocationStreet");
    xmlGet.find("ncreq:StreetNumberText");
    str26 = xmlGet.getString();
    xmlGet.find("ncreq:StreetName");
    str27 = xmlGet.getString();
    xmlGet.rise();
    xmlGet.find("ncreq:LocationCityName");
    str28 = xmlGet.getString();
    xmlGet.find("dsp917cajudreq:LocationStateUSPostalServiceCode");
    str29 = xmlGet.getString();
    xmlGet.find("ncreq:LocationPostalCode");
    str30 = xmlGet.getString();
    xmlGet.rise();
    xmlGet.rise();
    xmlGet.rise();
    xmlGet.rise();
    xmlGet.findAndDescend("dsp917cajudreq:ProductRelatedOrganizations");
    xmlGet.findAndDescend("dsp917cajudreq:Court");
    xmlGet.findAndDescend("dsp917cajudreq:OrganizationCourtIdentification");
    xmlGet.find("ncreq:IdentificationID");
    str31 = xmlGet.getString();
    xmlGet.rise();
    xmlGet.rise();
    xmlGet.rise();
    xmlGet.findAndDescend("dsp917cajudreq:ProductRelatedPeople");
    xmlGet.findAndDescend("dsp917cajudreq:Person");
    xmlGet.findAndDescend("dsp917cajudreq:PersonBirth");
    xmlGet.findAndDescend("ncreq:PersonBirthDate");
    xmlGet.find("ncreq:Date");
    str32 = xmlGet.getString();
    xmlGet.rise();
    xmlGet.rise();
    xmlGet.findAndDescend("dsp917cajudreq:PersonDemographics");
    xmlGet.find("dsp917cajudreq:PersonEyeColorCode");
    str33 = xmlGet.getString();
    xmlGet.find("dsp917cajudreq:PersonHairColorCode");
    str34 = xmlGet.getString();
    xmlGet.findAndDescend("ncreq:PersonHeightMeasure");
    xmlGet.find("ncreq:MeasureText");
    str35 = xmlGet.getString();
    xmlGet.rise();
    xmlGet.find("dsp917cajudreq:PersonSexCode");
    str36 = xmlGet.getString();
    xmlGet.findAndDescend("ncreq:PersonWeightMeasure");
    xmlGet.find("ncreq:MeasureText");
    str37 = xmlGet.getString();
    xmlGet.rise();
    xmlGet.rise();
    xmlGet.findAndDescend("dsp917cajudreq:PersonName");
    xmlGet.find("ncreq:PersonGivenName");
    str38 = xmlGet.getString();
    xmlGet.find("ncreq:PersonMiddleName");
    str39 = xmlGet.getString();
    xmlGet.find("ncreq:PersonSurName");
    str40 = xmlGet.getString();
    xmlGet.rise();
    xmlGet.rise();
// OTHER PROTECTED
    xmlGet.findNextAndDescend("dsp917cajudreq:Person");
    xmlGet.findNextAndDescend("dsp917cajudreq:PersonBirth");
    xmlGet.findNextAndDescend("ncreq:PersonBirthDate");
    xmlGet.find("ncreq:Date");
    str41 = xmlGet.getString();
    xmlGet.rise();
    xmlGet.rise();
    xmlGet.findNextAndDescend("dsp917cajudreq:PersonDemographics");
    xmlGet.findNext("dsp917cajudreq:PersonSexCode");
    str42 = xmlGet.getString();
    xmlGet.rise();
    xmlGet.findNextAndDescend("dsp917cajudreq:PersonName");
    xmlGet.findNext("ncreq:PersonGivenName");
    str43 = xmlGet.getString();
    xmlGet.findNext("ncreq:PersonSurName");
    str44 = xmlGet.getString();
    xmlGet.rise();
    xmlGet.rise();
    xmlGet.findNextAndDescend("dsp917cajudreq:Person");
    xmlGet.findNextAndDescend("dsp917cajudreq:PersonBirth");
    xmlGet.findNextAndDescend("ncreq:PersonBirthDate");
    xmlGet.findNext("ncreq:Date");
    str45 = xmlGet.getString();
    xmlGet.rise();
    xmlGet.rise();
    xmlGet.findNextAndDescend("dsp917cajudreq:PersonDemographics");
    xmlGet.findNext("dsp917cajudreq:PersonSexCode");
    str46 = xmlGet.getString();
    xmlGet.rise();
    xmlGet.findNextAndDescend("dsp917cajudreq:PersonName");
    xmlGet.findNext("ncreq:PersonGivenName");
    str47 = xmlGet.getString();
    xmlGet.findNext("ncreq:PersonSurName");
    str48 = xmlGet.getString();
    xmlGet.rise();
    xmlGet.rise();
 //RESTRAINED PARTY INFO
    xmlGet.findNextAndDescend("dsp917cajudreq:Person");
    xmlGet.findNextAndDescend("dsp917cajudreq:PersonBirth");
    xmlGet.findNextAndDescend("ncreq:PersonBirthDate");
    xmlGet.findNext("ncreq:Date");
    str49 = xmlGet.getString();
    xmlGet.rise();
    xmlGet.rise();
    xmlGet.findNextAndDescend("dsp917cajudreq:PersonDemographics");
    xmlGet.findNext("dsp917cajudreq:PersonEyeColorCode");
    str50 = xmlGet.getString();
    xmlGet.findNext("dsp917cajudreq:PersonHairColorCode");
    str51 = xmlGet.getString();
    xmlGet.findNextAndDescend("ncreq:PersonHeightMeasure");
    xmlGet.findNext("ncreq:MeasureText");
    str52 = xmlGet.getString();
    xmlGet.rise();
    xmlGet.findNext("dsp917cajudreq:PersonRaceCode");
    str53 = xmlGet.getString();
    xmlGet.findNext("dsp917cajudreq:PersonSexCode");
    str54 = xmlGet.getString();
    xmlGet.findNextAndDescend("ncreq:PersonWeightMeasure");
    xmlGet.findNext("ncreq:MeasureText");
    str55 = xmlGet.getString();
    xmlGet.rise();
    xmlGet.rise();
    xmlGet.findNextAndDescend("dsp917cajudreq:PersonName");
    xmlGet.findNext("ncreq:PersonGivenName");
    str56 = xmlGet.getString();
    xmlGet.findNext("ncreq:PersonMiddleName");
    str57 = xmlGet.getString();
    xmlGet.findNext("ncreq:PersonSurName");
    str58 = xmlGet.getString();
    xmlGet.rise();
    xmlGet.rise();
    xmlGet.rise();
    xmlGet.rise();
    xmlGet.findNextAndDescend("dsp917cajudreq:RestrainedParticipantPersonContactInformationAssociation");
    xmlGet.findNext("dsp917cajudreq:ContactInformationCategoryAddressTypeCode");
    str59 = xmlGet.getString();

//DISPLAY UI
    ui->lineEdit_activityYr->setText(str1);
    ui->lineEdit_caseExtID->setText(str2);
    ui->lineEdit_caseDocketID->setText(str3);
    ui->lineEdit_caseNumber->setText(str3);
    ui->lineEdit_orderType->setText(str4);
    ui->lineEdit_exportStatus->setText(str5);
    ui->lineEdit_confidentialCode->setText(str6);
    ui->lineEdit_contact->setText(str7);
    ui->lineEdit_courtName->setText(str8);
    ui->lineEdit_caseExpireDate->setText(str9);
    ui->lineEdit_firearms->setText(str10);
    ui->lineEdit_ordersIssued->setText(str11);
    ui->lineEdit_issuanceState->setText(str12);
    ui->lineEdit_caseIssueDate->setText(str13);
    ui->lineEdit_noexpire->setText(str14);
    ui->lineEdit_present->setText(str15);
    ui->lineEdit_documentCatagoryText->setText(str16);
    ui->lineEdit_caseType->setText(str17);
    ui->lineEdit_caseSealed->setText(str18);
    ui->lineEdit_stayaway->setText(str19);
    ui->lineEdit_staydistance->setText(str20);
    ui->lineEdit_agency->setText(str21);
    ui->lineEdit_p1Entity->setText(str22);
    ui->lineEdit_p2Entity->setText(str25);
    ui->lineEdit_o1Entity->setText(str23);
    ui->lineEdit_o2Entity->setText(str24);
    ui->lineEdit_c1Number->setText(str26);
    ui->lineEdit_c1Street->setText(str27);

    ui->lineEdit_c1City->setText(str28);
    ui->lineEdit_c1State->setText(str29);
    ui->lineEdit_c1Postal->setText(str30);

    ui->lineEdit_courtid->setText(str31);
    ui->lineEdit_p1DOB->setText(str32);
    ui->lineEdit_p1eyes->setText(str33);
    ui->lineEdit_p1hair->setText(str34);
    ui->lineEdit_p1height->setText(str35);
    ui->lineEdit_p1sex->setText(str36);
    ui->lineEdit_p1weight->setText(str37);
    ui->lineEdit_p1fname->setText(str38);
    ui->lineEdit_p1mname->setText(str39);
    ui->lineEdit_p1lname->setText(str40);

    ui->lineEdit_o1DOB->setText(str41);
    ui->lineEdit_o1Sex->setText(str42);
    ui->lineEdit_o1fname->setText(str43);
    ui->lineEdit_o1lname->setText(str44);

    ui->lineEdit_o2DOB->setText(str45);
    ui->lineEdit_o2Sex->setText(str46);
    ui->lineEdit_o2fname->setText(str47);
    ui->lineEdit_o2lname->setText(str48);

    ui->lineEdit_p2DOB->setText(str49);
    ui->lineEdit_p2eyes->setText(str50);
    ui->lineEdit_p2hair->setText(str51);
    ui->lineEdit_p2height->setText(str52);
    ui->lineEdit_p2race->setText(str53);
    ui->lineEdit_p2sex->setText(str54);
    ui->lineEdit_p2weight->setText(str55);
    ui->lineEdit_p2fname->setText(str56);
    ui->lineEdit_p2mname->setText(str57);
    ui->lineEdit_p2lname->setText(str58);
    ui->lineEdit_c1AddressType->setText(str59);
}

//FUNCTION TO SAVE CCPOR XML FORMAT
void MainWindow::saveFile()
{
    QString str1;
    QString str2;
    QString str3;
    QString str4;
    QString str5;
    QString str6;
    QString str7;
    QString str8;
    QString str9;
    QString str10;
    QString str11;
    QString str12;
    QString str13;
    QString str14;
    QString str15;
    QString str16;
    QString str17;
    QString str18;
    QString str19;
    QString str20;
    QString str21;
    QString str22;
    QString str23;
    QString str24;
    QString str25;
    QString str26;
    QString str27;
    QString str28;
    QString str29;
    QString str30;
    QString str31;
    QString str32;
    QString str33;
    QString str34;
    QString str35;
    QString str36;
    QString str37;
    QString str38;
    QString str39;
    QString str40;
    QString str41;
    QString str42;
    QString str43;
    QString str44;
    QString str45;
    QString str46;
    QString str47;
    QString str48;
    QString str49;
    QString str50;
    QString str51;
    QString str52;
    QString str53;
    QString str54;
    QString str55;
    QString str56;
    QString str57;
    QString str58;
    QString str59;
    QString str60;
    QString str61;
    QString str62;
    QString str63;
    QString usr1;
    QString usr2;
    QString password;
    QString url;
    QString ordertype;
    QString casetype;
    QString streetnumber;
    QString streetname;
    QString addresstype;
    QString addresscity;
    QString addressstate;
    QString addresspostal;
    QString namecode = "NAMEONCASE";

    url = ui->lineEdit_wsseURL->text();
    usr1=ui->lineEdit_wsseUser->text();
    password=ui->lineEdit_wssePassword->text();
    str1=ui->lineEdit_source->text();
    str2=ui->lineEdit_target->text();
    str3=ui->lineEdit_interfaceName->text();
    str4=ui->lineEdit_documentType->text();
    str5=ui->lineEdit_correlationID->text();
    str6=ui->lineEdit_ISBTransactionId->text();
    str7=ui->lineEdit_environment->text();
    str8=ui->lineEdit_hostname->text();
    str9=ui->lineEdit_currentTime->text();
    str10=ui->lineEdit_courtCode->text();
    usr2=ui->lineEdit_userID->text();
    str11=ui->lineEdit_activityYr->text();
    str12=ui->lineEdit_caseExtID->text();
    str13=ui->lineEdit_caseNumber->text();
    str15=ui->lineEdit_documentCatagoryText->text();
    str16=ui->lineEdit_exportStatus->text();
    str17=ui->lineEdit_confidentialCode->text();
    str18=ui->lineEdit_contact->text();

    str19=ui->lineEdit_courtName->text();;
    str20=ui->lineEdit_caseExpireDate->text();
    str21=ui->lineEdit_firearms->text();
    str22=ui->lineEdit_issuanceState->text();
    str23=ui->lineEdit_caseIssueDate->text();
    str24=ui->lineEdit_noexpire->text();
    str25=ui->lineEdit_present->text();
    str26=ui->lineEdit_ordersIssued->text();
    str27=ui->lineEdit_caseSealed->text();
    str28=ui->lineEdit_stayaway->text();
    str29=ui->lineEdit_staydistance->text();
    str30=ui->lineEdit_agency->text();
    str31=ui->lineEdit_p1Entity->text();
    str32=ui->lineEdit_p2Entity->text();
    str33=ui->lineEdit_courtid->text();
    ordertype=ui->lineEdit_orderType->text();
    casetype=ui->lineEdit_caseType->text();

    str34=ui->lineEdit_p1DOB->text();
    str35=ui->lineEdit_p1eyes->text();
    str36=ui->lineEdit_p1hair->text();
    str37=ui->lineEdit_p1height->text();
    str39=ui->lineEdit_p1sex->text();
    str40=ui->lineEdit_p1weight->text();
    str41=ui->lineEdit_p1fname->text();
    str42=ui->lineEdit_p1mname->text();
    str43=ui->lineEdit_p1lname->text();

    str44=ui->lineEdit_p2DOB->text();
    str45=ui->lineEdit_p2eyes->text();
    str46=ui->lineEdit_p2hair->text();
    str47=ui->lineEdit_p2height->text();
    str48=ui->lineEdit_p2race->text();
    str49=ui->lineEdit_p2sex->text();
    str50=ui->lineEdit_p2weight->text();
    str51=ui->lineEdit_p2fname->text();
    str52=ui->lineEdit_p2mname->text();
    str53=ui->lineEdit_p2lname->text();

//EXTENDED CASE DATA
    str54=ui->lineEdit_o1Entity->text();
    str55=ui->lineEdit_o1fname->text();
    str56=ui->lineEdit_o1lname->text();
    str57=ui->lineEdit_o1DOB->text();
    str58=ui->lineEdit_o1Sex->text();
    str59=ui->lineEdit_o2Entity->text();
    str60=ui->lineEdit_o2fname->text();
    str61=ui->lineEdit_o2lname->text();
    str62=ui->lineEdit_o2DOB->text();
    str63=ui->lineEdit_o2Sex->text();

    streetnumber=ui->lineEdit_c1Number->text();
    streetname=ui->lineEdit_c1Street->text();
    addresstype=ui->lineEdit_c1AddressType->text();
    addresscity=ui->lineEdit_c1City->text();
    addressstate=ui->lineEdit_c1State->text();
    addresspostal=ui->lineEdit_c1Postal->text();


    QXmlPut xmlPut("soapenv:Envelope");
    xmlPut.setAttributeString("xmlns:soapenv", "http://schemas.xmlsoap.org/soap/envelope/");
    xmlPut.descend("soapenv:Header");
    xmlPut.descend("wsse:Security");
    xmlPut.setAttributeString("soapenv:mustUnderstand", "1");
    xmlPut.descend("wsse:UsernameToken");
    xmlPut.putString("wsse:Username", usr1);
    xmlPut.putString("wsse:Password", password);
    xmlPut.setAttributeString("Type", "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordText");
    xmlPut.rise();
    xmlPut.rise();
    xmlPut.rise();
    xmlPut.descend("soapenv:Body");
    xmlPut.descend("dsp917cajudreqip:DSP917CAJUDReqInput");
    xmlPut.descend("tnshdr:ISBCommonServiceHeader");
    xmlPut.putString("Source", str1);
        xmlPut.setAttributeString("xmlns", "");
    xmlPut.putString("Target", str2);
        xmlPut.setAttributeString("xmlns", "");
    xmlPut.putString("InterfaceName", str3);
        xmlPut.setAttributeString("xmlns", "");
    xmlPut.putString("DocumentType", str4);
        xmlPut.setAttributeString("xmlns", "");
    xmlPut.putString("CorrelationId", str5);
        xmlPut.setAttributeString("xmlns", "");
    xmlPut.putString("ISBTransactionId", str6);
        xmlPut.setAttributeString("xmlns", "");
    xmlPut.putString("Environment", str7);
        xmlPut.setAttributeString("xmlns", "");
    xmlPut.putString("Hostname", str8);
        xmlPut.setAttributeString("xmlns", "");
    xmlPut.putString("TimeStamp", str9);
        xmlPut.setAttributeString("xmlns", "");
    xmlPut.putString("CourtCd", str10);
        xmlPut.setAttributeString("xmlns", "");
    xmlPut.putString("UserId", usr2);
    xmlPut.setAttributeString("xmlns", "");
    xmlPut.rise();
    xmlPut.descend("dsp917cajudreq:ProductExchangePackage");
    xmlPut.descend("dsp917cajudreq:ProductRelatedObjects");
    xmlPut.descend("dsp917cajudreq:ProductRelatedActivities");
    xmlPut.descend("dsp917cajudreq:CourtCase");
    xmlPut.descend("ncreq:ActivityDate");
    xmlPut.putString("ncreq:Year", str11);
    xmlPut.rise();
    xmlPut.descend("dsp917cajudreq:CaseAugmentation");
    xmlPut.descend("jreq:CaseOtherIdentification");
    xmlPut.putString("ncreq:IdentificationID", str12);
    xmlPut.rise();
    xmlPut.rise();
    xmlPut.putString("ncreq:CaseDocketID", str13);
    xmlPut.descend("dsp917cajudreq:CaseRestrainingOrder");
    xmlPut.putString("ncreq:ActivityCategoryText", str15);
    xmlPut.putString("dsp917cajudreq:AddUpdateCancelText", str16);
    xmlPut.putString("dsp917cajudreq:ConfidentialCode", str17);
    xmlPut.putString("dsp917cajudreq:ContactAllowedCode", str18);
    xmlPut.putString("jreq:CourtName", str19);
    xmlPut.descend("ncreq:ExpirationDate");
    xmlPut.putString("ncreq:Date", str20);
    xmlPut.rise();
    xmlPut.putString("dsp917cajudreq:FirearmProvisionsCode", str21);
    xmlPut.putString("ncreq:IdentificationID", ordertype);
    xmlPut.putString("dsp917cajudreq:IssuanceStateCode", str22);
    xmlPut.descend("dsp917cajudreq:IssuedDate");
    xmlPut.putString("ncreq:Date", str23);
    xmlPut.rise();
    xmlPut.putString("dsp917cajudreq:NeverExpiresCode", str24);
    xmlPut.putString("dsp917cajudreq:PresentInCourtCode", str25);
    xmlPut.descend("dsp917cajudreq:RestrainingOrderAttachment");
    xmlPut.descend("ncreq:DocumentBinary");
    xmlPut.putString("ncreq:BinaryBase64Object", "objectfile_payload");
    xmlPut.rise();
    xmlPut.putString("ncreq:DocumentCategoryText", str26);
    xmlPut.putString("ncreq:DocumentDescriptionText", casetype);
    xmlPut.putString("ncreq:DocumentFormatCategoryText", "MIME");
    xmlPut.putString("ncreq:DocumentTitleText", "DV110_22-1251.pdf");
    xmlPut.rise();
    xmlPut.putString("dsp917cajudreq:SealedCode", str27);
    xmlPut.putString("dsp917cajudreq:StayAwayText", str28);
    xmlPut.putString("dsp917cajudreq:YardsToStayAwayQuantity", str29);
    xmlPut.rise();
    xmlPut.putString("dsp917cajudreq:OriginatingAgencyID", str30);
    xmlPut.descend("dsp917cajudreq:ProtectedParticipant");
    xmlPut.putString("dsp917cajudreq:ParticipantCategoryCode", str31);
    xmlPut.descend("dsp917cajudreq:RoleOfEntity");
    xmlPut.putString("dsp917cajudreq:EntityRoleCode", "PPSC");
    xmlPut.putSingleTag("ncreq:RoleOfPersonReference");
    xmlPut.setAttributeString("s:ref", "PRO_1");
    xmlPut.rise();
    xmlPut.rise();
    xmlPut.descend("dsp917cajudreq:ProtectedParticipant");
    xmlPut.putString("dsp917cajudreq:ParticipantCategoryCode", str54);
    xmlPut.descend("dsp917cajudreq:RoleOfEntity");
    xmlPut.putString("dsp917cajudreq:EntityRoleCode", "APPSC");
    xmlPut.putSingleTag("ncreq:RoleOfPersonReference");
    xmlPut.setAttributeString("s:ref", "PRO_2");
    xmlPut.rise();
    xmlPut.rise();
    xmlPut.descend("dsp917cajudreq:ProtectedParticipant");
    xmlPut.putString("dsp917cajudreq:ParticipantCategoryCode", str59);
    xmlPut.descend("dsp917cajudreq:RoleOfEntity");
    xmlPut.putString("dsp917cajudreq:EntityRoleCode", "APPSC");
    xmlPut.putSingleTag("ncreq:RoleOfPersonReference");
    xmlPut.setAttributeString("s:ref", "PRO_3");
    xmlPut.rise();
    xmlPut.rise();
    xmlPut.descend("dsp917cajudreq:RestrainedParticipant");
    xmlPut.putString("dsp917cajudreq:ParticipantCategoryCode", str32);
    xmlPut.descend("dsp917cajudreq:RoleOfEntity");
    xmlPut.putString("dsp917cajudreq:EntityRoleCode", "RESPER");
    xmlPut.putSingleTag("ncreq:RoleOfPersonReference");
    xmlPut.setAttributeString("s:ref", "RES_1");
    xmlPut.rise();
    xmlPut.rise();
    xmlPut.rise();
    xmlPut.rise();
    xmlPut.descend("dsp917cajudreq:ProductRelatedContactInformation");
    xmlPut.descend("dsp917cajudreq:ContactInformation");
    xmlPut.setAttributeString("s:id", "CON_1");
    xmlPut.descend("ncreq:ContactMailingAddress");
    xmlPut.descend("ncreq:StructuredAddress");
    xmlPut.descend("dsp917cajudreq:LocationStreet");
    xmlPut.putString("ncreq:StreetNumberText",  streetnumber);
    xmlPut.putString("ncreq:StreetName",  streetname);
    xmlPut.rise();
    xmlPut.putString("ncreq:LocationCityName", addresscity);
    xmlPut.putString("dsp917cajudreq:LocationStateUSPostalServiceCode", addressstate);
    xmlPut.putString("ncreq:LocationPostalCode", addresspostal);
    xmlPut.rise();
    xmlPut.rise();
    xmlPut.rise();
    xmlPut.rise();
    xmlPut.descend("dsp917cajudreq:ProductRelatedOrganizations");
    xmlPut.descend("dsp917cajudreq:Court");
    xmlPut.descend("dsp917cajudreq:OrganizationCourtIdentification");
    xmlPut.putString("ncreq:IdentificationID", str33);
    xmlPut.rise();
    xmlPut.rise();
    xmlPut.rise();
    xmlPut.descend("dsp917cajudreq:ProductRelatedPeople");
    xmlPut.descend("dsp917cajudreq:Person");
        xmlPut.setAttributeString("s:id", "PRO_1");
    xmlPut.descend("dsp917cajudreq:PersonBirth");
    xmlPut.descend("ncreq:PersonBirthDate");
    xmlPut.putString("ncreq:Date", str34);
    xmlPut.rise();
    xmlPut.rise();
    xmlPut.descend("dsp917cajudreq:PersonDemographics");
    xmlPut.putString("dsp917cajudreq:PersonEyeColorCode", str35);
    xmlPut.putString("dsp917cajudreq:PersonHairColorCode", str36);
    xmlPut.descend("ncreq:PersonHeightMeasure");
    xmlPut.putString("ncreq:MeasureText", str37);
    xmlPut.rise();
    xmlPut.putString("dsp917cajudreq:PersonRaceCode", str38);
    xmlPut.putString("dsp917cajudreq:PersonSexCode", str39);
    xmlPut.descend("ncreq:PersonWeightMeasure");
    xmlPut.putString("ncreq:MeasureText", str40);
    xmlPut.rise();
    xmlPut.rise();
    xmlPut.descend("dsp917cajudreq:PersonName");
    xmlPut.putString("dsp917cajudreq:PersonCaseNameCategoryCode", namecode);
    xmlPut.putString("ncreq:PersonGivenName", str41);
    xmlPut.putString("ncreq:PersonMiddleName", str42);
    xmlPut.putString("ncreq:PersonSurName", str43);
    xmlPut.rise();
    xmlPut.rise();
    xmlPut.descend("dsp917cajudreq:Person");
        xmlPut.setAttributeString("s:id", "PRO_2");
    xmlPut.descend("dsp917cajudreq:PersonBirth");
    xmlPut.descend("ncreq:PersonBirthDate");
    xmlPut.putString("ncreq:Date", str57);
    xmlPut.rise();
    xmlPut.rise();
    xmlPut.descend("dsp917cajudreq:PersonDemographics");
    xmlPut.putString("dsp917cajudreq:PersonSexCode", str58);
    xmlPut.rise();
    xmlPut.descend("dsp917cajudreq:PersonName");
    xmlPut.putString("dsp917cajudreq:PersonCaseNameCategoryCode", namecode);
    xmlPut.putString("ncreq:PersonGivenName", str55);
    xmlPut.putString("ncreq:PersonSurName", str56);
    xmlPut.rise();
    xmlPut.rise();
    xmlPut.descend("dsp917cajudreq:Person");
        xmlPut.setAttributeString("s:id", "PRO_3");
    xmlPut.descend("dsp917cajudreq:PersonBirth");
    xmlPut.descend("ncreq:PersonBirthDate");
    xmlPut.putString("ncreq:Date", str62);
    xmlPut.rise();
    xmlPut.rise();
    xmlPut.descend("dsp917cajudreq:PersonDemographics");
    xmlPut.putString("dsp917cajudreq:PersonSexCode", str63);
    xmlPut.rise();
    xmlPut.descend("dsp917cajudreq:PersonName");
    xmlPut.putString("dsp917cajudreq:PersonCaseNameCategoryCode", namecode);
    xmlPut.putString("ncreq:PersonGivenName", str60);
    xmlPut.putString("ncreq:PersonSurName", str61);
    xmlPut.rise();
    xmlPut.rise();
    xmlPut.descend("dsp917cajudreq:Person");
        xmlPut.setAttributeString("s:id", "RES_1");
    xmlPut.descend("dsp917cajudreq:PersonBirth");
    xmlPut.descend("ncreq:PersonBirthDate");
    xmlPut.putString("ncreq:Date", str44);
    xmlPut.rise();
    xmlPut.rise();
    xmlPut.descend("dsp917cajudreq:PersonDemographics");
    xmlPut.putString("dsp917cajudreq:PersonEyeColorCode", str45);
    xmlPut.putString("dsp917cajudreq:PersonHairColorCode", str46);
    xmlPut.descend("ncreq:PersonHeightMeasure");
    xmlPut.putString("ncreq:MeasureText", str47);
    xmlPut.rise();
    xmlPut.putString("dsp917cajudreq:PersonRaceCode", str48);
    xmlPut.putString("dsp917cajudreq:PersonSexCode", str49);
    xmlPut.descend("ncreq:PersonWeightMeasure");
    xmlPut.putString("ncreq:MeasureText", str50);
    xmlPut.rise();
    xmlPut.rise();
    xmlPut.descend("dsp917cajudreq:PersonName");
    xmlPut.putString("dsp917cajudreq:PersonCaseNameCategoryCode", namecode);
    xmlPut.putString("ncreq:PersonGivenName", str51);
    xmlPut.putString("ncreq:PersonMiddleName", str52);
    xmlPut.putString("ncreq:PersonSurName", str53);
    xmlPut.rise();
    xmlPut.rise();
    xmlPut.rise();
    xmlPut.rise();
    xmlPut.descend("dsp917cajudreq:RestrainedParticipantPersonContactInformationAssociation");
    xmlPut.putString("dsp917cajudreq:ContactInformationCategoryAddressTypeCode", addresstype);
    xmlPut.putSingleTag("ncreq:ContactInformationReference");
        xmlPut.setAttributeString("s:ref", "CON_1");
    xmlPut.putSingleTag("ncreq:PersonReference");
        xmlPut.setAttributeString("s:ref", "RES_1");
    xmlPut.rise();

    QString savefile;
    savefile = ui->lineEdit_saveFile->text();

    xmlPut.save(savefile);
}

void MainWindow::on_toolButton_clicked()
{
    ui->lineEdit_source->clear();
    ui->lineEdit_target->clear();
     ui->lineEdit_interfaceName->clear();
     ui->lineEdit_documentType->clear();
     ui->lineEdit_correlationID->clear();
     ui->lineEdit_ISBTransactionId->clear();
     ui->lineEdit_environment->clear();
     ui->lineEdit_hostname->clear();
     ui->lineEdit_timestamp->clear();
     ui->lineEdit_courtCode->clear();
     ui->lineEdit_confidentialCode->clear();
     ui->lineEdit_issuanceState->clear();
     ui->lineEdit_activityYr->clear();
     ui->lineEdit_caseNumber->clear();
     ui->lineEdit_orderType->clear();
     ui->lineEdit_exportStatus->clear();
     ui->lineEdit_caseSealed->clear();
     ui->lineEdit_contact->clear();
     ui->lineEdit_courtName->clear();
     ui->lineEdit_caseExpireDate->clear();
     ui->lineEdit_firearms->clear();
     ui->lineEdit_noexpire->clear();
     ui->lineEdit_present->clear();
     ui->lineEdit_ordersIssued->clear();
     ui->lineEdit_stayaway->clear();
     ui->lineEdit_staydistance->clear();
     ui->lineEdit_agency->clear();
     ui->lineEdit_p1Entity->clear();
     ui->lineEdit_p2Entity->clear();
     ui->lineEdit_courtid->clear();
     ui->lineEdit_documentCatagoryText->clear();
     ui->lineEdit_caseIssueDate->clear();
     ui->lineEdit_caseDocketID->clear();
     ui->lineEdit_p1DOB->clear();
     ui->lineEdit_p1eyes->clear();
     ui->lineEdit_p1hair->clear();
     ui->lineEdit_p1sex->clear();
     ui->lineEdit_p1weight->clear();
     ui->lineEdit_p1height->clear();
     ui->lineEdit_p1fname->clear();
     ui->lineEdit_p1mname->clear();
     ui->lineEdit_p1lname->clear();
     ui->lineEdit_p2DOB->clear();
     ui->lineEdit_p2eyes->clear();
     ui->lineEdit_p2hair->clear();
     ui->lineEdit_p2race->clear();
     ui->lineEdit_p2sex->clear();
     ui->lineEdit_p2weight->clear();
     ui->lineEdit_p2height->clear();
     ui->lineEdit_p2fname->clear();
     ui->lineEdit_p2mname->clear();
     ui->lineEdit_p2lname->clear();
     ui->lineEdit_caseExtID->clear();
     ui->lineEdit_orderType->clear();
     ui->lineEdit_caseType->clear();
     ui->lineEdit_o1Entity->clear();
     ui->lineEdit_o1fname->clear();
     ui->lineEdit_o1lname->clear();
     ui->lineEdit_o1DOB->clear();
     ui->lineEdit_o1Sex->clear();
     ui->lineEdit_o2Entity->clear();
     ui->lineEdit_o2fname->clear();
     ui->lineEdit_o2lname->clear();
     ui->lineEdit_o2DOB->clear();
     ui->lineEdit_o2Sex->clear();
     ui->lineEdit_c1Number->clear();
     ui->lineEdit_c1Street->clear();
     ui->lineEdit_c1AddressType->clear();
     ui->lineEdit_c1City->clear();
     ui->lineEdit_c1State->clear();
     ui->lineEdit_c1Postal->clear();

}

void MainWindow::on_toolButton_2_clicked()
{
    QApplication::exit(0);
}

MainWindow::~MainWindow()
{
    delete ui;
}
