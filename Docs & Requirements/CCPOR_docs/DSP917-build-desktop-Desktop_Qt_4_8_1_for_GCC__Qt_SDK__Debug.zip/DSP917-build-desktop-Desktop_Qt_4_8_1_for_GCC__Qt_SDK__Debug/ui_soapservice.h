/********************************************************************************
** Form generated from reading UI file 'soapservice.ui'
**
** Created: Thu Aug 8 19:00:40 2013
**      by: Qt User Interface Compiler version 4.8.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SOAPSERVICE_H
#define UI_SOAPSERVICE_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QHeaderView>

QT_BEGIN_NAMESPACE

class Ui_SoapService
{
public:

    void setupUi(QDialog *SoapService)
    {
        if (SoapService->objectName().isEmpty())
            SoapService->setObjectName(QString::fromUtf8("SoapService"));
        SoapService->resize(400, 300);

        retranslateUi(SoapService);

        QMetaObject::connectSlotsByName(SoapService);
    } // setupUi

    void retranslateUi(QDialog *SoapService)
    {
        SoapService->setWindowTitle(QApplication::translate("SoapService", "Dialog", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class SoapService: public Ui_SoapService {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SOAPSERVICE_H
