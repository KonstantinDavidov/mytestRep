/********************************************************************************
** Form generated from reading UI file 'response.ui'
**
** Created: Thu Aug 8 19:00:40 2013
**      by: Qt User Interface Compiler version 4.8.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_RESPONSE_H
#define UI_RESPONSE_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QFrame>
#include <QtGui/QGroupBox>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QTextEdit>
#include <QtGui/QToolButton>

QT_BEGIN_NAMESPACE

class Ui_Response
{
public:
    QLabel *label_source_14;
    QLabel *label_source_6;
    QLabel *label_source_8;
    QLabel *label_source_19;
    QLabel *label_source_11;
    QLineEdit *lineEdit_target;
    QLineEdit *lineEdit_controlNumber;
    QLabel *label_source_12;
    QLineEdit *lineEdit_orderType;
    QLabel *label_source_13;
    QLabel *label_source_4;
    QLabel *label_source_7;
    QLineEdit *lineEdit_distributionID;
    QLineEdit *lineEdit_environment;
    QLineEdit *lineEdit_ccporID;
    QLineEdit *lineEdit_userID;
    QLineEdit *lineEdit_correlationID;
    QLineEdit *lineEdit_documentID;
    QFrame *frame_2;
    QLabel *label_2;
    QLabel *label_source_5;
    QLineEdit *lineEdit_hostname;
    QLineEdit *lineEdit_courtCode;
    QLineEdit *lineEdit_documentType;
    QLineEdit *lineEdit_interfaceName;
    QLabel *label_source_52;
    QLineEdit *lineEdit_ISBTransactionId;
    QLabel *label_source_2;
    QLabel *label_source_15;
    QFrame *line;
    QLineEdit *lineEdit_source;
    QLabel *label_source;
    QFrame *frame;
    QLabel *label;
    QLabel *label_source_3;
    QGroupBox *groupBox;
    QToolButton *toolButton;
    QFrame *frame_3;
    QLabel *label_source_17;
    QLineEdit *lineEdit_error;
    QLabel *label_source_20;
    QLabel *label_source_21;
    QTextEdit *textEdit;
    QLabel *label_source_18;
    QLineEdit *lineEdit_timeStamp;

    void setupUi(QDialog *Response)
    {
        if (Response->objectName().isEmpty())
            Response->setObjectName(QString::fromUtf8("Response"));
        Response->resize(509, 389);
        QFont font;
        font.setPointSize(11);
        Response->setFont(font);
        label_source_14 = new QLabel(Response);
        label_source_14->setObjectName(QString::fromUtf8("label_source_14"));
        label_source_14->setGeometry(QRect(260, 65, 66, 21));
        QFont font1;
        font1.setPointSize(11);
        font1.setBold(true);
        font1.setWeight(75);
        label_source_14->setFont(font1);
        label_source_14->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        label_source_6 = new QLabel(Response);
        label_source_6->setObjectName(QString::fromUtf8("label_source_6"));
        label_source_6->setGeometry(QRect(15, 215, 86, 21));
        label_source_6->setFont(font1);
        label_source_6->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        label_source_8 = new QLabel(Response);
        label_source_8->setObjectName(QString::fromUtf8("label_source_8"));
        label_source_8->setGeometry(QRect(15, 265, 58, 21));
        label_source_8->setFont(font1);
        label_source_8->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        label_source_19 = new QLabel(Response);
        label_source_19->setObjectName(QString::fromUtf8("label_source_19"));
        label_source_19->setGeometry(QRect(15, 190, 86, 21));
        label_source_19->setFont(font1);
        label_source_19->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        label_source_11 = new QLabel(Response);
        label_source_11->setObjectName(QString::fromUtf8("label_source_11"));
        label_source_11->setGeometry(QRect(15, 290, 76, 21));
        label_source_11->setFont(font1);
        label_source_11->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        lineEdit_target = new QLineEdit(Response);
        lineEdit_target->setObjectName(QString::fromUtf8("lineEdit_target"));
        lineEdit_target->setGeometry(QRect(115, 65, 125, 21));
        lineEdit_controlNumber = new QLineEdit(Response);
        lineEdit_controlNumber->setObjectName(QString::fromUtf8("lineEdit_controlNumber"));
        lineEdit_controlNumber->setGeometry(QRect(360, 40, 141, 21));
        label_source_12 = new QLabel(Response);
        label_source_12->setObjectName(QString::fromUtf8("label_source_12"));
        label_source_12->setGeometry(QRect(260, 40, 96, 21));
        label_source_12->setFont(font1);
        label_source_12->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        lineEdit_orderType = new QLineEdit(Response);
        lineEdit_orderType->setObjectName(QString::fromUtf8("lineEdit_orderType"));
        lineEdit_orderType->setGeometry(QRect(339, 90, 161, 21));
        label_source_13 = new QLabel(Response);
        label_source_13->setObjectName(QString::fromUtf8("label_source_13"));
        label_source_13->setGeometry(QRect(15, 140, 91, 21));
        label_source_13->setFont(font1);
        label_source_13->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        label_source_4 = new QLabel(Response);
        label_source_4->setObjectName(QString::fromUtf8("label_source_4"));
        label_source_4->setGeometry(QRect(15, 115, 89, 21));
        label_source_4->setFont(font1);
        label_source_4->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        label_source_7 = new QLabel(Response);
        label_source_7->setObjectName(QString::fromUtf8("label_source_7"));
        label_source_7->setGeometry(QRect(15, 240, 72, 21));
        label_source_7->setFont(font1);
        label_source_7->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        lineEdit_distributionID = new QLineEdit(Response);
        lineEdit_distributionID->setObjectName(QString::fromUtf8("lineEdit_distributionID"));
        lineEdit_distributionID->setGeometry(QRect(115, 190, 126, 21));
        lineEdit_environment = new QLineEdit(Response);
        lineEdit_environment->setObjectName(QString::fromUtf8("lineEdit_environment"));
        lineEdit_environment->setGeometry(QRect(115, 240, 125, 21));
        lineEdit_ccporID = new QLineEdit(Response);
        lineEdit_ccporID->setObjectName(QString::fromUtf8("lineEdit_ccporID"));
        lineEdit_ccporID->setGeometry(QRect(339, 65, 161, 21));
        lineEdit_userID = new QLineEdit(Response);
        lineEdit_userID->setObjectName(QString::fromUtf8("lineEdit_userID"));
        lineEdit_userID->setGeometry(QRect(115, 315, 125, 21));
        lineEdit_correlationID = new QLineEdit(Response);
        lineEdit_correlationID->setObjectName(QString::fromUtf8("lineEdit_correlationID"));
        lineEdit_correlationID->setGeometry(QRect(115, 165, 125, 21));
        lineEdit_documentID = new QLineEdit(Response);
        lineEdit_documentID->setObjectName(QString::fromUtf8("lineEdit_documentID"));
        lineEdit_documentID->setGeometry(QRect(115, 140, 126, 21));
        frame_2 = new QFrame(Response);
        frame_2->setObjectName(QString::fromUtf8("frame_2"));
        frame_2->setGeometry(QRect(251, 0, 258, 26));
        frame_2->setStyleSheet(QString::fromUtf8("background-color: rgb(153, 209, 160);"));
        frame_2->setFrameShape(QFrame::StyledPanel);
        frame_2->setFrameShadow(QFrame::Raised);
        label_2 = new QLabel(frame_2);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(10, 5, 131, 16));
        label_2->setFont(font1);
        label_source_5 = new QLabel(Response);
        label_source_5->setObjectName(QString::fromUtf8("label_source_5"));
        label_source_5->setGeometry(QRect(15, 165, 80, 21));
        label_source_5->setFont(font1);
        label_source_5->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        lineEdit_hostname = new QLineEdit(Response);
        lineEdit_hostname->setObjectName(QString::fromUtf8("lineEdit_hostname"));
        lineEdit_hostname->setGeometry(QRect(115, 265, 125, 21));
        lineEdit_courtCode = new QLineEdit(Response);
        lineEdit_courtCode->setObjectName(QString::fromUtf8("lineEdit_courtCode"));
        lineEdit_courtCode->setGeometry(QRect(115, 290, 125, 21));
        lineEdit_documentType = new QLineEdit(Response);
        lineEdit_documentType->setObjectName(QString::fromUtf8("lineEdit_documentType"));
        lineEdit_documentType->setGeometry(QRect(115, 115, 125, 21));
        lineEdit_interfaceName = new QLineEdit(Response);
        lineEdit_interfaceName->setObjectName(QString::fromUtf8("lineEdit_interfaceName"));
        lineEdit_interfaceName->setGeometry(QRect(115, 90, 125, 21));
        label_source_52 = new QLabel(Response);
        label_source_52->setObjectName(QString::fromUtf8("label_source_52"));
        label_source_52->setGeometry(QRect(15, 315, 64, 21));
        label_source_52->setFont(font1);
        label_source_52->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        lineEdit_ISBTransactionId = new QLineEdit(Response);
        lineEdit_ISBTransactionId->setObjectName(QString::fromUtf8("lineEdit_ISBTransactionId"));
        lineEdit_ISBTransactionId->setGeometry(QRect(115, 215, 125, 21));
        label_source_2 = new QLabel(Response);
        label_source_2->setObjectName(QString::fromUtf8("label_source_2"));
        label_source_2->setGeometry(QRect(15, 65, 56, 21));
        label_source_2->setFont(font1);
        label_source_2->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        label_source_15 = new QLabel(Response);
        label_source_15->setObjectName(QString::fromUtf8("label_source_15"));
        label_source_15->setGeometry(QRect(260, 90, 82, 21));
        label_source_15->setFont(font1);
        label_source_15->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        line = new QFrame(Response);
        line->setObjectName(QString::fromUtf8("line"));
        line->setGeometry(QRect(241, 0, 16, 341));
        line->setFrameShape(QFrame::VLine);
        line->setFrameShadow(QFrame::Sunken);
        lineEdit_source = new QLineEdit(Response);
        lineEdit_source->setObjectName(QString::fromUtf8("lineEdit_source"));
        lineEdit_source->setGeometry(QRect(115, 40, 125, 21));
        label_source = new QLabel(Response);
        label_source->setObjectName(QString::fromUtf8("label_source"));
        label_source->setGeometry(QRect(15, 40, 71, 21));
        label_source->setFont(font1);
        label_source->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        frame = new QFrame(Response);
        frame->setObjectName(QString::fromUtf8("frame"));
        frame->setGeometry(QRect(0, 0, 246, 26));
        frame->setFont(font);
        frame->setStyleSheet(QString::fromUtf8("background-color: rgb(131, 182, 199);"));
        frame->setFrameShape(QFrame::StyledPanel);
        frame->setFrameShadow(QFrame::Raised);
        label = new QLabel(frame);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(10, 5, 131, 16));
        label->setFont(font1);
        label_source_3 = new QLabel(Response);
        label_source_3->setObjectName(QString::fromUtf8("label_source_3"));
        label_source_3->setGeometry(QRect(15, 90, 86, 21));
        label_source_3->setFont(font1);
        label_source_3->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        groupBox = new QGroupBox(Response);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        groupBox->setGeometry(QRect(10, 345, 491, 34));
        toolButton = new QToolButton(groupBox);
        toolButton->setObjectName(QString::fromUtf8("toolButton"));
        toolButton->setGeometry(QRect(400, 5, 81, 23));
        frame_3 = new QFrame(Response);
        frame_3->setObjectName(QString::fromUtf8("frame_3"));
        frame_3->setGeometry(QRect(255, 195, 246, 141));
        frame_3->setFrameShape(QFrame::StyledPanel);
        frame_3->setFrameShadow(QFrame::Raised);
        label_source_17 = new QLabel(frame_3);
        label_source_17->setObjectName(QString::fromUtf8("label_source_17"));
        label_source_17->setGeometry(QRect(5, 0, 76, 21));
        label_source_17->setFont(font1);
        label_source_17->setStyleSheet(QString::fromUtf8("color: rgb(191, 0, 71);"));
        label_source_17->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        lineEdit_error = new QLineEdit(frame_3);
        lineEdit_error->setObjectName(QString::fromUtf8("lineEdit_error"));
        lineEdit_error->setGeometry(QRect(65, 25, 176, 21));
        label_source_20 = new QLabel(frame_3);
        label_source_20->setObjectName(QString::fromUtf8("label_source_20"));
        label_source_20->setGeometry(QRect(10, 25, 71, 21));
        label_source_20->setFont(font1);
        label_source_20->setStyleSheet(QString::fromUtf8("color: rgb(191, 0, 71);"));
        label_source_20->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        label_source_21 = new QLabel(frame_3);
        label_source_21->setObjectName(QString::fromUtf8("label_source_21"));
        label_source_21->setGeometry(QRect(10, 50, 71, 21));
        label_source_21->setFont(font1);
        label_source_21->setStyleSheet(QString::fromUtf8("color: rgb(191, 0, 71);"));
        label_source_21->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        textEdit = new QTextEdit(frame_3);
        textEdit->setObjectName(QString::fromUtf8("textEdit"));
        textEdit->setGeometry(QRect(10, 75, 231, 56));
        label_source_18 = new QLabel(Response);
        label_source_18->setObjectName(QString::fromUtf8("label_source_18"));
        label_source_18->setGeometry(QRect(260, 115, 71, 21));
        label_source_18->setFont(font1);
        label_source_18->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        lineEdit_timeStamp = new QLineEdit(Response);
        lineEdit_timeStamp->setObjectName(QString::fromUtf8("lineEdit_timeStamp"));
        lineEdit_timeStamp->setGeometry(QRect(265, 135, 236, 21));

        retranslateUi(Response);
        QObject::connect(toolButton, SIGNAL(clicked()), Response, SLOT(close()));

        QMetaObject::connectSlotsByName(Response);
    } // setupUi

    void retranslateUi(QDialog *Response)
    {
        Response->setWindowTitle(QApplication::translate("Response", "CCPOR Response", 0, QApplication::UnicodeUTF8));
        label_source_14->setText(QApplication::translate("Response", "CCPOR ID", 0, QApplication::UnicodeUTF8));
        label_source_6->setText(QApplication::translate("Response", "ISB Trans. ID", 0, QApplication::UnicodeUTF8));
        label_source_8->setText(QApplication::translate("Response", "Hostname", 0, QApplication::UnicodeUTF8));
        label_source_19->setText(QApplication::translate("Response", "Distribution ID", 0, QApplication::UnicodeUTF8));
        label_source_11->setText(QApplication::translate("Response", "Court Code", 0, QApplication::UnicodeUTF8));
        label_source_12->setText(QApplication::translate("Response", "Control Number", 0, QApplication::UnicodeUTF8));
        label_source_13->setText(QApplication::translate("Response", "Document ID", 0, QApplication::UnicodeUTF8));
        label_source_4->setText(QApplication::translate("Response", "Document Type", 0, QApplication::UnicodeUTF8));
        label_source_7->setText(QApplication::translate("Response", "Environment", 0, QApplication::UnicodeUTF8));
        label_2->setText(QApplication::translate("Response", "CCPOR", 0, QApplication::UnicodeUTF8));
        label_source_5->setText(QApplication::translate("Response", "Correlation ID", 0, QApplication::UnicodeUTF8));
        label_source_52->setText(QApplication::translate("Response", "UserID", 0, QApplication::UnicodeUTF8));
        label_source_2->setText(QApplication::translate("Response", "Target", 0, QApplication::UnicodeUTF8));
        label_source_15->setText(QApplication::translate("Response", "Order Entry", 0, QApplication::UnicodeUTF8));
        label_source->setText(QApplication::translate("Response", "Source", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("Response", "ISB NameSpace", 0, QApplication::UnicodeUTF8));
        label_source_3->setText(QApplication::translate("Response", "Interface Name", 0, QApplication::UnicodeUTF8));
        groupBox->setTitle(QString());
        toolButton->setText(QApplication::translate("Response", "DONE", 0, QApplication::UnicodeUTF8));
        label_source_17->setText(QApplication::translate("Response", "ERRORS", 0, QApplication::UnicodeUTF8));
        label_source_20->setText(QApplication::translate("Response", "Code", 0, QApplication::UnicodeUTF8));
        label_source_21->setText(QApplication::translate("Response", "Message", 0, QApplication::UnicodeUTF8));
        label_source_18->setText(QApplication::translate("Response", "TimeStamp", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class Response: public Ui_Response {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_RESPONSE_H
